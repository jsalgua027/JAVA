/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio9;

/**
 *
 * @author nacho
 */
public abstract class Vehiculo {
    
    
    
private int bastidor;

public final void setBastidor(int bastidor){
    
    this.bastidor = bastidor;}

public abstract int getVelocidad();

}
