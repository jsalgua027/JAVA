/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio8;

/**
 *
 * @author JoseIgnacio
 */
public abstract class Azar {

    protected int posibilidades;

    public abstract int lanzar();
}
