/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio8;

import java.util.Random;

/**
 *
 * @author JoseIgnacio
 */
public class Dado extends Azar {

    Random Aleatorio = new Random();

    @Override
    public int lanzar() {
        int resultado = Aleatorio.nextInt(6 + 1) + 1;
        return resultado;
    }

}
