
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author JoseIgnacio
 */
public class Lectura {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //fichero a leer
        String idFichero = "RelPerCen.csv";

        // variables para guardar datos a leer
        ArrayList<Profesores> listaProfesores = new ArrayList<>();
        String[] tokens;
        String linea;
        // creo el map para la segunda fase del ejercicio
        Map<String, Integer>cantidadProfesoresDepartamento = new HashMap<>();
        // muestro por consola el fichero a leer
        System.out.println("Leyendo el fichero: " + idFichero);

        // inicializo el flujo de lectura en funcion del idFichero
        try (Scanner datosFichero = new Scanner(new File(idFichero),"ISO-8859-1")) {

            datosFichero.nextLine();

            while (datosFichero.hasNextLine()) {

                linea = datosFichero.nextLine();
                // el metodo replaceAll quita el caracter que (yo quiera y despues lo que quieres dejar) en este caso barra invertida porque es una comilla
                linea = linea.replaceAll("\"", "");

                // Se guarda en el array de String cada elemento de la
                // línea en función del carácter separador coma
                tokens = linea.split(",");
                // imprimo cada linea 
                System.out.println(linea + "\t");

                Profesores p1 = new Profesores();
                p1.setApellidos(tokens[0]);
                p1.setNombre(tokens[1]);
                p1.setDni(tokens[2]);
                p1.setPuesto(tokens[3]);
                //todo lo que recibimos es tipo string entonces lo trasformamos a Localdate 
                //!!!!OJO tenemos que decirle al LocalDate como va a recibir el formato del tiempo
                //!!!OJO en el documento el string tiene comillas el parse da error para ello hemos usado el replaceAll de la linea 47
                p1.setFechaTomaPosesion(LocalDate.parse(tokens[4], DateTimeFormatter.ofPattern("d/MM/yyyy")));
                //!!OJO si nos encontramos campos vacios nos da error, para trabajar eso usmos esta condicion 
                if(tokens[5].equalsIgnoreCase("")){ // el método equals reconoce el espacio, si queremos un campo en blaco las comillas juntas
                    p1.setFechaCese(null);
                }else{
                   p1.setFechaCese(LocalDate.parse(tokens[5], DateTimeFormatter.ofPattern("d/MM/yyyy"))); 
                }
                // recibimos un string pero el atributo de la POJO(profesores) es un boolean para ello usamos la condicion 
                p1.setTelefono(tokens[6]);
                if (tokens[7].equalsIgnoreCase("si")) {
                    p1.setEvaluador(true);
                } else {
                    p1.setEvaluador(false);

                }
                if (tokens[8].equalsIgnoreCase("si")) {
                    p1.setCoordinador(true);
                } else {
                    p1.setCoordinador(false);

                }

                listaProfesores.add(p1);
                 
                
                
                
            }

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
        // imprimo el arrayList de profesores
        for (Profesores listaP : listaProfesores) {
            System.out.println(listaP.toString());
        }
        // en este for metemos en el map los puestos, si creamos una variable para que si se encuentra el mismo puesto 
        // le haga una suma pq sino machacaria el valor y solo nos apareceria un profesor por puesto
        for (Profesores profe : listaProfesores) {
            if(cantidadProfesoresDepartamento.containsKey(profe.getPuesto())){
                int control=cantidadProfesoresDepartamento.get(profe.getPuesto());
                cantidadProfesoresDepartamento.put(profe.getPuesto(), control+1);
            }else{
               cantidadProfesoresDepartamento.put(profe.getPuesto(), 1); 
            }
            
            
        }
        // comienzo la escritura 
        
         String idFichero2 =  "profesoresPorDepartamento.csv";

       
       

        //     Map<String, Integer>cantidadProfesoresDepartamento = new HashMap<>();
        try ( BufferedWriter flujo = new BufferedWriter(new FileWriter(idFichero2))) {
               for (Map.Entry<String, Integer> entry : cantidadProfesoresDepartamento.entrySet()) {
                   
                flujo.write("El departamento de:  "+entry.getKey()+"tiene "+ entry.getValue()+ " profesores");
                flujo.newLine();
            }
      
            flujo.flush();
            System.out.println("Fichero " + idFichero2 + " creado correctamente.");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        
            System.out.println("----------------------------uso de metodos--------------");
        
        Utils metodosUtiles = new Utils();
         
        System.out.println(metodosUtiles.seEncuentraEnLaLista(listaProfesores, "Cristina"));
        
         int resultado=metodosUtiles.cuantosHayEnLaLista(listaProfesores, "Matemáticas P.E.S");
         System.out.println(resultado);
         
    }

}
