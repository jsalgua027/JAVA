/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

import java.util.Objects;

/**
 *
 * @author nacho
 */
public class Municipio {
    
    
    private String codigoM;
    private String nombre;
    private double porcentaje2016;
    private double porcentaje2015;
    private double porcentaje2014;
    private double porcentaje2013;
    private double porcentaje2012;
    private double porcentaje2011;
    private double porcentaje2010;
    private double porcentaje2006;
    private double porcentaje2001;
    private double porcentaje1996;
    

    public Municipio() {
        
               
    }

    public String getCodigoM() {
        return codigoM;
    }

    public void setCodigoM(String codigoM) {
        this.codigoM = codigoM;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPorcentaje2016() {
        return porcentaje2016;
    }

    public void setPorcentaje2016(double porcentaje2016) {
        this.porcentaje2016 = porcentaje2016;
    }

    public double getPorcentaje2015() {
        return porcentaje2015;
    }

    public void setPorcentaje2015(double porcentaje2015) {
        this.porcentaje2015 = porcentaje2015;
    }

    public double getPorcentaje2014() {
        return porcentaje2014;
    }

    public void setPorcentaje2014(double porcentaje2014) {
        this.porcentaje2014 = porcentaje2014;
    }

    public double getPorcentaje2013() {
        return porcentaje2013;
    }

    public void setPorcentaje2013(double porcentaje2013) {
        this.porcentaje2013 = porcentaje2013;
    }

    public double getPorcentaje2012() {
        return porcentaje2012;
    }

    public void setPorcentaje2012(double porcentaje2012) {
        this.porcentaje2012 = porcentaje2012;
    }

    public double getPorcentaje2011() {
        return porcentaje2011;
    }

    public void setPorcentaje2011(double porcentaje2011) {
        this.porcentaje2011 = porcentaje2011;
    }

    public double getPorcentaje2010() {
        return porcentaje2010;
    }

    public void setPorcentaje2010(double porcentaje2010) {
        this.porcentaje2010 = porcentaje2010;
    }

    public double getPorcentaje2006() {
        return porcentaje2006;
    }

    public void setPorcentaje2006(double porcentaje2006) {
        this.porcentaje2006 = porcentaje2006;
    }

    public double getPorcentaje2001() {
        return porcentaje2001;
    }

    public void setPorcentaje2001(double porcentaje2001) {
        this.porcentaje2001 = porcentaje2001;
    }

    public double getPorcentaje1996() {
        return porcentaje1996;
    }

    public void setPorcentaje1996(double porcentaje1996) {
        this.porcentaje1996 = porcentaje1996;
    }

    @Override
    public String toString() {
        return "Municipio{" + "codigoM=" + codigoM + ", nombre=" + nombre + ", porcentaje2016=" + porcentaje2016 + ", porcentaje2015=" + porcentaje2015 + ", porcentaje2014=" + porcentaje2014 + ", porcentaje2013=" + porcentaje2013 + ", porcentaje2012=" + porcentaje2012 + ", porcentaje2011=" + porcentaje2011 + ", porcentaje2010=" + porcentaje2010 + ", porcentaje2006=" + porcentaje2006 + ", porcentaje2001=" + porcentaje2001 + ", porcentaje1996=" + porcentaje1996 + '}';
    }
    
    
    
    
   
    }
    
    
    
    
    
    
    

