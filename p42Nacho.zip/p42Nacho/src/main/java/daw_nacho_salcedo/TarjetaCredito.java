/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package daw_nacho_salcedo;

import java.time.LocalDate;
import java.time.Month;
import java.time.YearMonth;

/**
 *
 * @author nacho
 */
public class TarjetaCredito {

    private String numtarjeta;
    private int limite;
    private boolean tarjEstado;//true desactivada
    private int pin;
    private String nomEntidad;
    private String titular;
    private LocalDate fechaVencimiento;

    //constructor por defecto
    public TarjetaCredito() {
        this.numtarjeta = "1234567891112345";
        this.tarjEstado = true;
        this.limite = 2500;
        this.pin = 1234;
        this.nomEntidad = "BBVA";
        this.titular = "Pepe perez";
        this.fechaVencimiento = LocalDate.of(12, 25, 2023);

    }

    //constructor parametrizado
    public TarjetaCredito(String numtarjeta, int limite, boolean tarjEstado,
            int pin, String nomEntidad, String titular, LocalDate fechaVencimiento) {

        if (numtarjeta.length() == 16) { //comprobacion tarjeta tiene 16 cifas
            this.numtarjeta = numtarjeta;
        } else {
            this.numtarjeta = "1234123412341234";
        }
        if (limite >= 500 && limite <= 3000) {// limite de credito
            this.limite = limite;
        } else {
            this.limite = 550;
        }

        this.tarjEstado = tarjEstado;

        this.pin = pin;

        this.nomEntidad = nomEntidad;
        this.titular = titular;

        if (fechaVencimiento.isBefore(LocalDate.now())) {               // si la tarjeta esta caducada se crea otra con 5 años mas 
            this.fechaVencimiento = LocalDate.now().plusYears(5);

        } else {
            this.fechaVencimiento = fechaVencimiento;

        }

    }

    public String getNumtarjeta() {
        return numtarjeta;
    }

    public void setNumtarjeta(String numtarjeta) {
        if (numtarjeta.length() == 16) { //comprobacion tarjeta tiene 16 cifas
            this.numtarjeta = numtarjeta;
        } else {
            this.numtarjeta = "1234123412341234";
        }

    }

    public int getLimite() {
        return limite;
    }

    public void setLimite(int limite) {
        if (limite >= 500 && limite <= 3000) {// limite de credito
            this.limite = limite;
        } else {
            this.limite = 300;
        }

    }

    public boolean isTarjEstado() {
        return tarjEstado;
    }

    public void setTarjEstado(boolean tarjEstado) {
        this.tarjEstado = tarjEstado;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public String getNomEntidad() {
        return nomEntidad;
    }

    public void setNomEntidad(String nomEntidad) {
        this.nomEntidad = nomEntidad;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public LocalDate getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(LocalDate fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    //metodo copia 
    public TarjetaCredito copia(TarjetaCredito aux) {
        TarjetaCredito nueva = new TarjetaCredito(aux.getNumtarjeta(), aux.getLimite(), aux.isTarjEstado(), aux.getPin(),
                aux.getNomEntidad(), aux.getTitular(), aux.getFechaVencimiento());
        return nueva;
    }

    //metodo toString
    @Override
    public String toString() {
        return "TarjetaCredito{" + "\n Nombre del titular= " + titular + "\nCon fecha de vencimiento= "
                + fechaVencimiento + "\nUn credito de= " + limite + "\nCon el nuemro de tarjeta= " + numtarjeta
                + '}';
    }
     
    
     
}
